# LLM Interview Research Assistant

This repo shows how to make an LLM assisted research assistant